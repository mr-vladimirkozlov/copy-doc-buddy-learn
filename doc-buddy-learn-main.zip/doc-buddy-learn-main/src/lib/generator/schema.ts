import { z } from "zod";

export const DOCUMENT_TYPES = [
  { id: "policy", title: "Политика обработки персональных данных", filename: "Политика-обработки-ПДн" },
  { id: "cookie", title: "Политика использования файлов cookie", filename: "Политика-cookie" },
  { id: "consent_form", title: "Согласие на обработку ПДн (для форм)", filename: "Согласие-на-обработку-ПДн" },
  { id: "consent_cookie", title: "Согласие на использование cookie", filename: "Согласие-cookie" },
  { id: "consent_mailing", title: "Согласие на рекламную рассылку", filename: "Согласие-на-рассылку" },
  { id: "consent_dissemination", title: "Согласие на распространение ПДн", filename: "Согласие-на-распространение" },
  { id: "terms", title: "Пользовательское соглашение", filename: "Пользовательское-соглашение" },
] as const;

export type DocumentId = (typeof DOCUMENT_TYPES)[number]["id"];

export const SITE_FEATURES = [
  { id: "forms", label: "Формы обратной связи / заявки" },
  { id: "cookie", label: "Файлы cookie" },
  { id: "analytics", label: "Яндекс.Метрика / Google Analytics" },
  { id: "payments", label: "Онлайн-оплата (эквайринг)" },
  { id: "account", label: "Личный кабинет / регистрация" },
  { id: "callback", label: "Заказ обратного звонка" },
  { id: "delivery", label: "Доставка товаров" },
  { id: "crm", label: "CRM-система" },
  { id: "mailing", label: "Email-рассылки" },
  { id: "chat", label: "Онлайн-чат" },
  { id: "reviews", label: "Публикация отзывов / фото клиентов" },
] as const;

export type FeatureId = (typeof SITE_FEATURES)[number]["id"];

export const DATA_CATEGORIES = [
  { id: "name", label: "ФИО" },
  { id: "email", label: "Email" },
  { id: "phone", label: "Телефон" },
  { id: "address", label: "Почтовый адрес" },
  { id: "passport", label: "Паспортные данные" },
  { id: "payment", label: "Платёжные реквизиты" },
  { id: "cookies", label: "Cookie / идентификаторы устройства" },
  { id: "ip", label: "IP-адрес" },
  { id: "behavior", label: "Поведенческие данные (метрики)" },
  { id: "photo", label: "Фото / видео" },
] as const;

export type DataCategoryId = (typeof DATA_CATEGORIES)[number]["id"];

export const THIRD_PARTY_PRESETS = [
  "Хостинг-провайдер",
  "CRM-система",
  "Сервис email-рассылок",
  "Платёжный агрегатор / банк",
  "Курьерская служба / почта",
  "Сервисы веб-аналитики (Яндекс, Google)",
  "Сервис телефонии / колл-трекинг",
  "Подрядчики разработки и поддержки",
];

export const formSchema = z.object({
  documents: z.array(z.string()).min(1, "Выберите хотя бы один документ"),
  operator: z.object({
    name: z.string().trim().min(2, "Укажите наименование").max(255),
    inn: z.string().trim().regex(/^(\d{10}|\d{12})$/, "ИНН должен быть 10 или 12 цифр"),
    ogrn: z.string().trim().max(15).optional().or(z.literal("")),
    address: z.string().trim().min(5, "Укажите юридический адрес").max(500),
    email: z.string().trim().email("Некорректный email").max(255),
    phone: z.string().trim().min(5, "Укажите телефон").max(50),
  }),
  site: z.object({
    domain: z.string().trim().min(3, "Укажите домен").max(255),
    name: z.string().trim().max(255).optional().or(z.literal("")),
  }),
  features: z.array(z.string()),
  thirdParties: z.array(z.string().min(1).max(255)),
  dataCategories: z.array(z.string()),
  purposes: z.string().trim().max(2000).optional().or(z.literal("")),
  crossBorder: z.boolean(),
  crossBorderCountries: z.string().trim().max(500).optional().or(z.literal("")),
  hostingRussia: z.boolean(),
  effectiveDate: z.string().trim().max(20).optional().or(z.literal("")),
});

export type FormData = z.infer<typeof formSchema>;

export const defaultFormData: FormData = {
  documents: DOCUMENT_TYPES.map((d) => d.id),
  operator: { name: "", inn: "", ogrn: "", address: "", email: "", phone: "" },
  site: { domain: "", name: "" },
  features: ["forms", "cookie", "analytics"],
  thirdParties: ["Хостинг-провайдер", "Сервисы веб-аналитики (Яндекс, Google)"],
  dataCategories: ["name", "email", "phone", "cookies", "ip"],
  purposes: "Обработка заявок и обращений, информирование о статусе заказа, улучшение работы сайта.",
  crossBorder: false,
  crossBorderCountries: "",
  hostingRussia: true,
  effectiveDate: "",
};
