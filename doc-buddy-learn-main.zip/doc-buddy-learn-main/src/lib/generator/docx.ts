import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from "docx";
import { saveAs } from "file-saver";
import JSZip from "jszip";
import type { GeneratedDocument } from "./templates";

function buildDocx(doc: GeneratedDocument): Document {
  const children: Paragraph[] = [];

  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      heading: HeadingLevel.HEADING_1,
      children: [new TextRun({ text: doc.title, bold: true, size: 32 })],
      spacing: { after: 300 },
    }),
  );

  for (const s of doc.sections) {
    if (s.heading) {
      children.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          children: [new TextRun({ text: s.heading, bold: true, size: 26 })],
          spacing: { before: 240, after: 120 },
        }),
      );
    }
    for (const p of s.paragraphs) {
      children.push(
        new Paragraph({
          children: [new TextRun({ text: p, size: 22 })],
          spacing: { after: 120 },
          alignment: AlignmentType.JUSTIFIED,
        }),
      );
    }
  }

  return new Document({
    styles: {
      default: { document: { run: { font: "Times New Roman", size: 22 } } },
    },
    sections: [
      {
        properties: {
          page: {
            size: { width: 11906, height: 16838 },
            margin: { top: 1134, bottom: 1134, left: 1701, right: 1134 },
          },
        },
        children,
      },
    ],
  });
}

export async function downloadDocx(doc: GeneratedDocument) {
  const blob = await Packer.toBlob(buildDocx(doc));
  saveAs(blob, `${doc.filename}.docx`);
}

export async function downloadAllZip(docs: GeneratedDocument[]) {
  const zip = new JSZip();
  for (const d of docs) {
    const blob = await Packer.toBlob(buildDocx(d));
    zip.file(`${d.filename}.docx`, blob);
  }
  const out = await zip.generateAsync({ type: "blob" });
  saveAs(out, "documenty-152-fz.zip");
}
