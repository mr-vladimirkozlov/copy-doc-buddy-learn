import type { FormData } from "./schema";
import { defaultFormData } from "./schema";

const KEY = "fz152-generator-form-v1";

export function loadForm(): FormData {
  if (typeof window === "undefined") return defaultFormData;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return defaultFormData;
    return { ...defaultFormData, ...JSON.parse(raw) };
  } catch {
    return defaultFormData;
  }
}

export function saveForm(data: FormData) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    // ignore
  }
}

export function clearForm() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(KEY);
}
