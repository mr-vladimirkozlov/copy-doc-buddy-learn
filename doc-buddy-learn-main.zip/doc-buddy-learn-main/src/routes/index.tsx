import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ShieldCheck, FileText, Cookie, ClipboardCheck, Mail, Share2, ScrollText, Lock } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Генератор документов 152-ФЗ — политика, согласия, оферта для сайта" },
      { name: "description", content: "Соберите комплект документов о персональных данных для вашего сайта за 5 минут. Бесплатно, без регистрации, без отправки данных на сервер." },
      { property: "og:title", content: "Генератор документов 152-ФЗ" },
      { property: "og:description", content: "Политика ПДн, cookie, согласия, оферта — готовый комплект .docx за 5 минут." },
    ],
  }),
  component: HomePage,
});

const DOCS = [
  { icon: ShieldCheck, title: "Политика обработки ПДн", desc: "17 разделов по требованиям ст. 18.1 152-ФЗ." },
  { icon: Cookie, title: "Политика cookie", desc: "Что и зачем собираем, как отказаться." },
  { icon: ClipboardCheck, title: "Согласие на обработку ПДн", desc: "Текст под чекбокс в формах." },
  { icon: Cookie, title: "Согласие на cookie", desc: "Для cookie-баннера на сайте." },
  { icon: Mail, title: "Согласие на рассылку", desc: "Для подписки на email-новости." },
  { icon: Share2, title: "Согласие на распространение", desc: "Для отзывов, фото клиентов." },
  { icon: ScrollText, title: "Пользовательское соглашение", desc: "Базовая оферта для сайта." },
];

function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_oklch(0.62_0.16_38/0.08),_transparent_60%)]" />
        <div className="mx-auto max-w-5xl px-4 pt-16 pb-12 md:px-8 md:pt-24 md:pb-20">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs">
            <Lock className="h-3 w-3" /> Все данные обрабатываются в вашем браузере
          </span>
          <h1 className="mt-6 font-serif text-5xl leading-[1.05] tracking-tight md:text-7xl">
            Документы 152-ФЗ <br />
            <span className="italic text-accent">за пять минут</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
            Заполните 7 простых шагов — получите комплект из политики обработки персональных данных,
            политики cookie, согласий и пользовательского соглашения. Скачайте .docx или скопируйте текст.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/generator"
              className="inline-flex items-center gap-2 rounded-md bg-accent px-6 py-3 text-base font-medium text-accent-foreground transition hover:bg-accent/90"
            >
              Сформировать документы <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/about"
              className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-6 py-3 text-base font-medium hover:border-accent"
            >
              Как это работает
            </Link>
          </div>
        </div>
      </section>

      {/* Documents grid */}
      <section className="mx-auto max-w-6xl px-4 py-16 md:px-8">
        <div className="mb-10 flex items-end justify-between gap-4">
          <h2 className="font-serif text-3xl md:text-4xl">7 документов в комплекте</h2>
          <p className="hidden max-w-sm text-sm text-muted-foreground md:block">
            Выбираете нужные — остальные не попадут в выгрузку.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {DOCS.map(({ icon: Icon, title, desc }) => (
            <article key={title} className="group rounded-xl border border-border bg-card p-6 transition hover:border-accent/60">
              <Icon className="h-6 w-6 text-accent" />
              <h3 className="mt-4 font-serif text-xl">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
            </article>
          ))}
        </div>
      </section>

      {/* How */}
      <section className="border-t border-border bg-muted/30">
        <div className="mx-auto max-w-5xl px-4 py-16 md:px-8">
          <h2 className="font-serif text-3xl md:text-4xl">Как это работает</h2>
          <ol className="mt-10 grid gap-8 md:grid-cols-3">
            {[
              { n: 1, t: "Заполняете форму", d: "Данные оператора, домен, что используется на сайте." },
              { n: 2, t: "Видите предпросмотр", d: "Документы собираются и подсвечивают незаполненные поля." },
              { n: 3, t: "Скачиваете .docx", d: "Один файл, все сразу ZIP-ом или копируете в буфер." },
            ].map((s) => (
              <li key={s.n}>
                <div className="font-serif text-5xl text-accent">{String(s.n).padStart(2, "0")}</div>
                <h3 className="mt-3 font-serif text-xl">{s.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-4xl px-4 py-20 text-center md:px-8">
        <FileText className="mx-auto h-10 w-10 text-accent" />
        <h2 className="mt-4 font-serif text-4xl md:text-5xl">Начните сейчас</h2>
        <p className="mt-4 text-muted-foreground">Бесплатно. Без регистрации. Без отправки данных на сервер.</p>
        <Link
          to="/generator"
          className="mt-8 inline-flex items-center gap-2 rounded-md bg-primary px-6 py-3 text-base font-medium text-primary-foreground hover:bg-primary/90"
        >
          Открыть генератор <ArrowRight className="h-4 w-4" />
        </Link>
      </section>
    </>
  );
}
