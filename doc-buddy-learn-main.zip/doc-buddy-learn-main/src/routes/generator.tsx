import { createFileRoute } from "@tanstack/react-router";
import { GeneratorForm } from "@/components/generator/GeneratorForm";

export const Route = createFileRoute("/generator")({
  head: () => ({
    meta: [
      { title: "Генератор документов 152-ФЗ — заполните форму" },
      { name: "description", content: "Заполните данные оператора и сайта — получите готовый комплект документов о персональных данных в .docx." },
      { property: "og:title", content: "Генератор 152-ФЗ — форма" },
      { property: "og:description", content: "Заполните форму и скачайте документы для сайта." },
    ],
  }),
  component: GeneratorPage,
});

function GeneratorPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 md:px-8 md:py-16">
      <header className="mb-10">
        <h1 className="font-serif text-4xl md:text-5xl">Генератор документов</h1>
        <p className="mt-3 text-muted-foreground">
          Заполните поля — мы соберём документы и подсветим то, что осталось дописать.
        </p>
      </header>
      <GeneratorForm />
    </div>
  );
}
