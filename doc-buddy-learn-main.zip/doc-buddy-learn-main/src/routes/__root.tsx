import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { Toaster } from "@/components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-7xl">404</h1>
        <p className="mt-2 text-sm text-muted-foreground">Страница не найдена.</p>
        <Link to="/" className="mt-6 inline-block text-accent underline">На главную</Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-2xl">Что-то пошло не так</h1>
        <p className="mt-2 text-sm text-muted-foreground">Попробуйте обновить страницу.</p>
        <button
          onClick={() => { router.invalidate(); reset(); }}
          className="mt-6 rounded-md bg-primary px-4 py-2 text-sm text-primary-foreground"
        >
          Повторить
        </button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Генератор документов 152-ФЗ — политика, согласия, оферта" },
      { name: "description", content: "Бесплатный генератор комплекта документов для сайта по 152-ФЗ: политика обработки ПДн, cookie, согласия, пользовательское соглашение. Скачивание .docx." },
      { property: "og:title", content: "Генератор документов 152-ФЗ — политика, согласия, оферта" },
      { property: "og:description", content: "Бесплатный генератор комплекта документов для сайта по 152-ФЗ: политика обработки ПДн, cookie, согласия, пользовательское соглашение. Скачивание .docx." },
      { property: "og:type", content: "website" },
      { name: "twitter:title", content: "Генератор документов 152-ФЗ — политика, согласия, оферта" },
      { name: "twitter:description", content: "Бесплатный генератор комплекта документов для сайта по 152-ФЗ: политика обработки ПДн, cookie, согласия, пользовательское соглашение. Скачивание .docx." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/d1615bcb-2079-475a-8ef1-fe89f2698ce0/id-preview-64884a81--5492f5be-ad4e-41fd-817f-8166ca6e24d6.lovable.app-1779725026491.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/d1615bcb-2079-475a-8ef1-fe89f2698ce0/id-preview-64884a81--5492f5be-ad4e-41fd-817f-8166ca6e24d6.lovable.app-1779725026491.png" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@400;500;600;700&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <head><HeadContent /></head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function Header() {
  return (
    <header className="no-print border-b border-border bg-background/80 backdrop-blur sticky top-0 z-30">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4 md:px-8">
        <Link to="/" className="flex items-center gap-2 font-serif text-xl">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm">§</span>
          <span>152-ФЗ <span className="text-accent">Docs</span></span>
        </Link>
        <nav className="flex items-center gap-1 text-sm">
          <Link to="/" className="px-3 py-2 hover:text-accent" activeProps={{ className: "px-3 py-2 text-accent" }} activeOptions={{ exact: true }}>
            Главная
          </Link>
          <Link to="/generator" className="px-3 py-2 hover:text-accent" activeProps={{ className: "px-3 py-2 text-accent" }}>
            Генератор
          </Link>
          <Link to="/about" className="px-3 py-2 hover:text-accent" activeProps={{ className: "px-3 py-2 text-accent" }}>
            О сервисе
          </Link>
        </nav>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="no-print mt-20 border-t border-border">
      <div className="mx-auto max-w-6xl px-4 py-8 text-xs text-muted-foreground md:px-8">
        <p>
          Сервис формирует типовые шаблоны документов в соответствии со структурой ФЗ-152.
          Не является юридической консультацией. Все данные обрабатываются локально в вашем браузере.
        </p>
        <p className="mt-2">© {new Date().getFullYear()} 152-ФЗ Docs</p>
      </div>
    </footer>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">
          <Outlet />
        </main>
        <Footer />
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}
