import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "О сервисе — Генератор документов 152-ФЗ" },
      { name: "description", content: "Зачем нужны документы по 152-ФЗ, как работает генератор, ограничения и дисклеймер." },
      { property: "og:title", content: "О сервисе 152-ФЗ Docs" },
      { property: "og:description", content: "Зачем нужны документы по 152-ФЗ и как работает наш генератор." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-16 md:px-8">
      <h1 className="font-serif text-5xl">О сервисе</h1>
      <p className="mt-6 text-lg text-muted-foreground">
        152-ФЗ Docs — бесплатный генератор типового комплекта документов о персональных данных для сайтов.
      </p>

      <h2 className="mt-12 font-serif text-3xl">Зачем это нужно</h2>
      <p className="mt-3">
        Согласно Федеральному закону от 27.07.2006 № 152-ФЗ, любой сайт, собирающий данные пользователей
        (формы, cookie, аналитика, регистрация, оплата), является оператором персональных данных. Закон
        требует опубликовать политику обработки и получать согласия — иначе грозят штрафы Роскомнадзора.
      </p>

      <h2 className="mt-10 font-serif text-3xl">Как работает</h2>
      <ul className="mt-3 space-y-2 list-disc pl-5">
        <li>Шаблоны хранятся в коде сервиса — они подставляют ваши данные в нужные места.</li>
        <li>Форма проверяет ИНН, email, домен и подсвечивает пропущенные поля.</li>
        <li>Документы собираются прямо в браузере: ничего не отправляется на сервер.</li>
        <li>Можно скачать .docx (по одному или всё ZIP-ом) или скопировать текст в буфер.</li>
      </ul>

      <h2 className="mt-10 font-serif text-3xl">Дисклеймер</h2>
      <p className="mt-3">
        Сервис формирует <strong>типовые шаблоны</strong>. Они закрывают базовые требования закона, но
        могут потребовать доработки под особенности вашего бизнеса. Не являются юридической консультацией.
        Перед публикацией рекомендуем проверку юристом и, при необходимости, подачу уведомления в
        Роскомнадзор (ст. 22 152-ФЗ).
      </p>

      <h2 className="mt-10 font-serif text-3xl">Приватность</h2>
      <p className="mt-3">
        Сервис не использует серверный бэкенд. Все введённые данные сохраняются только в локальном
        хранилище вашего браузера, чтобы при возвращении на страницу форма не оказалась пустой. Очистить
        данные можно кнопкой «Очистить» в генераторе.
      </p>

      <div className="mt-12">
        <Link
          to="/generator"
          className="inline-flex items-center gap-2 rounded-md bg-accent px-6 py-3 text-base font-medium text-accent-foreground hover:bg-accent/90"
        >
          Перейти к генератору
        </Link>
      </div>
    </article>
  );
}
