import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, X, Download, Copy, FileDown, RotateCcw, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  DOCUMENT_TYPES,
  SITE_FEATURES,
  DATA_CATEGORIES,
  THIRD_PARTY_PRESETS,
  formSchema,
  type FormData,
} from "@/lib/generator/schema";
import { loadForm, saveForm, clearForm } from "@/lib/generator/storage";
import { generateAll, documentToText } from "@/lib/generator/templates";
import { downloadDocx, downloadAllZip } from "@/lib/generator/docx";

type Errors = Partial<Record<string, string>>;

function flattenErrors(err: unknown): Errors {
  const out: Errors = {};
  // @ts-expect-error - zod error structure
  for (const issue of err?.issues ?? []) {
    out[issue.path.join(".")] = issue.message;
  }
  return out;
}

function FieldError({ msg }: { msg?: string }) {
  if (!msg) return null;
  return <p className="mt-1 text-xs text-destructive">{msg}</p>;
}

function Step({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-xl border border-border bg-card p-6 md:p-8">
      <header className="mb-5 flex items-center gap-4">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary font-serif text-lg text-primary-foreground">
          {n}
        </span>
        <h2 className="text-2xl font-serif">{title}</h2>
      </header>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

export function GeneratorForm() {
  const [form, setForm] = useState<FormData>(loadForm);
  const [errors, setErrors] = useState<Errors>({});
  const [generated, setGenerated] = useState(false);
  const [activeDoc, setActiveDoc] = useState<string>(DOCUMENT_TYPES[0].id);

  useEffect(() => {
    saveForm(form);
  }, [form]);

  const update = <K extends keyof FormData>(key: K, value: FormData[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const updateOp = (key: keyof FormData["operator"], value: string) =>
    setForm((f) => ({ ...f, operator: { ...f.operator, [key]: value } }));

  const toggleArr = (key: "documents" | "features" | "dataCategories", id: string) =>
    setForm((f) => {
      const arr = f[key];
      return {
        ...f,
        [key]: arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id],
      };
    });

  const docs = useMemo(() => generateAll(form), [form]);

  const handleGenerate = () => {
    const res = formSchema.safeParse(form);
    if (!res.success) {
      setErrors(flattenErrors(res.error));
      toast.error("Проверьте обязательные поля");
      return;
    }
    setErrors({});
    setGenerated(true);
    setActiveDoc(docs[0]?.id ?? DOCUMENT_TYPES[0].id);
    toast.success("Документы сформированы");
    setTimeout(() => document.getElementById("preview")?.scrollIntoView({ behavior: "smooth" }), 50);
  };

  const handleReset = () => {
    clearForm();
    setForm(loadForm());
    setGenerated(false);
    toast.success("Форма очищена");
  };

  const copy = (text: string) => {
    navigator.clipboard.writeText(text).then(() => toast.success("Скопировано в буфер обмена"));
  };

  return (
    <div className="space-y-8">
      {/* Step 1 — documents */}
      <Step n={1} title="Какие документы нужны">
        <div className="grid gap-3 sm:grid-cols-2">
          {DOCUMENT_TYPES.map((doc) => (
            <label
              key={doc.id}
              className="flex cursor-pointer items-start gap-3 rounded-md border border-border bg-background/50 p-3 hover:border-accent/60"
            >
              <Checkbox
                checked={form.documents.includes(doc.id)}
                onCheckedChange={() => toggleArr("documents", doc.id)}
                className="mt-0.5"
              />
              <span className="text-sm">{doc.title}</span>
            </label>
          ))}
        </div>
        <FieldError msg={errors["documents"]} />
      </Step>

      {/* Step 2 — operator */}
      <Step n={2} title="Данные оператора (владельца сайта)">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="md:col-span-2">
            <Label htmlFor="op-name">Полное наименование</Label>
            <Input
              id="op-name"
              placeholder="ООО «Ромашка» или ИП Иванов И. И."
              value={form.operator.name}
              onChange={(e) => updateOp("name", e.target.value)}
            />
            <FieldError msg={errors["operator.name"]} />
          </div>
          <div>
            <Label htmlFor="op-inn">ИНН</Label>
            <Input
              id="op-inn"
              inputMode="numeric"
              maxLength={12}
              value={form.operator.inn}
              onChange={(e) => updateOp("inn", e.target.value.replace(/\D/g, ""))}
            />
            <FieldError msg={errors["operator.inn"]} />
          </div>
          <div>
            <Label htmlFor="op-ogrn">ОГРН (необязательно)</Label>
            <Input
              id="op-ogrn"
              inputMode="numeric"
              maxLength={15}
              value={form.operator.ogrn ?? ""}
              onChange={(e) => updateOp("ogrn", e.target.value.replace(/\D/g, ""))}
            />
          </div>
          <div className="md:col-span-2">
            <Label htmlFor="op-addr">Юридический адрес</Label>
            <Input id="op-addr" value={form.operator.address} onChange={(e) => updateOp("address", e.target.value)} />
            <FieldError msg={errors["operator.address"]} />
          </div>
          <div>
            <Label htmlFor="op-email">Email для связи</Label>
            <Input id="op-email" type="email" value={form.operator.email} onChange={(e) => updateOp("email", e.target.value)} />
            <FieldError msg={errors["operator.email"]} />
          </div>
          <div>
            <Label htmlFor="op-phone">Телефон</Label>
            <Input id="op-phone" value={form.operator.phone} onChange={(e) => updateOp("phone", e.target.value)} />
            <FieldError msg={errors["operator.phone"]} />
          </div>
        </div>
      </Step>

      {/* Step 3 — site */}
      <Step n={3} title="Данные сайта">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <Label htmlFor="site-domain">Адрес сайта (домен)</Label>
            <Input
              id="site-domain"
              placeholder="https://example.ru"
              value={form.site.domain}
              onChange={(e) => update("site", { ...form.site, domain: e.target.value })}
            />
            <FieldError msg={errors["site.domain"]} />
          </div>
          <div>
            <Label htmlFor="site-name">Название (опционально)</Label>
            <Input
              id="site-name"
              value={form.site.name ?? ""}
              onChange={(e) => update("site", { ...form.site, name: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="effective">Дата вступления в силу</Label>
            <Input
              id="effective"
              placeholder="по умолчанию — сегодня"
              value={form.effectiveDate ?? ""}
              onChange={(e) => update("effectiveDate", e.target.value)}
            />
          </div>
        </div>
      </Step>

      {/* Step 4 — features */}
      <Step n={4} title="Что используется на сайте">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {SITE_FEATURES.map((f) => (
            <label
              key={f.id}
              className="flex cursor-pointer items-start gap-3 rounded-md border border-border bg-background/50 p-3 hover:border-accent/60"
            >
              <Checkbox
                checked={form.features.includes(f.id)}
                onCheckedChange={() => toggleArr("features", f.id)}
                className="mt-0.5"
              />
              <span className="text-sm">{f.label}</span>
            </label>
          ))}
        </div>
      </Step>

      {/* Step 5 — third parties */}
      <Step n={5} title="Передача данных третьим лицам">
        <p className="text-sm text-muted-foreground">
          Перечислите категории партнёров. Оставьте пустым, если данные третьим лицам не передаются.
        </p>
        <div className="space-y-2">
          {form.thirdParties.map((tp, i) => (
            <div key={i} className="flex gap-2">
              <Input
                value={tp}
                list="tp-presets"
                onChange={(e) => {
                  const next = [...form.thirdParties];
                  next[i] = e.target.value;
                  update("thirdParties", next);
                }}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => update("thirdParties", form.thirdParties.filter((_, j) => j !== i))}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <datalist id="tp-presets">
            {THIRD_PARTY_PRESETS.map((p) => <option key={p} value={p} />)}
          </datalist>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => update("thirdParties", [...form.thirdParties, ""])}
          >
            <Plus className="mr-1 h-4 w-4" /> Добавить
          </Button>
        </div>
      </Step>

      {/* Step 6 — data composition */}
      <Step n={6} title="Состав собираемых данных">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {DATA_CATEGORIES.map((c) => (
            <label
              key={c.id}
              className="flex cursor-pointer items-center gap-3 rounded-md border border-border bg-background/50 p-3 hover:border-accent/60"
            >
              <Checkbox
                checked={form.dataCategories.includes(c.id)}
                onCheckedChange={() => toggleArr("dataCategories", c.id)}
              />
              <span className="text-sm">{c.label}</span>
            </label>
          ))}
        </div>
        <div>
          <Label htmlFor="purposes">Цели обработки (кратко)</Label>
          <Textarea
            id="purposes"
            rows={3}
            value={form.purposes ?? ""}
            onChange={(e) => update("purposes", e.target.value)}
          />
        </div>
      </Step>

      {/* Step 7 — hosting + cross-border */}
      <Step n={7} title="Хостинг и трансграничная передача">
        <label className="flex cursor-pointer items-center gap-3 rounded-md border border-border bg-background/50 p-3">
          <Checkbox
            checked={form.hostingRussia}
            onCheckedChange={(v) => update("hostingRussia", Boolean(v))}
          />
          <span className="text-sm">Серверы (хостинг) расположены на территории РФ</span>
        </label>
        <label className="flex cursor-pointer items-center gap-3 rounded-md border border-border bg-background/50 p-3">
          <Checkbox
            checked={form.crossBorder}
            onCheckedChange={(v) => update("crossBorder", Boolean(v))}
          />
          <span className="text-sm">Осуществляется трансграничная передача персональных данных</span>
        </label>
        {form.crossBorder && (
          <div>
            <Label htmlFor="cbc">Страны передачи (через запятую)</Label>
            <Input
              id="cbc"
              value={form.crossBorderCountries ?? ""}
              onChange={(e) => update("crossBorderCountries", e.target.value)}
            />
          </div>
        )}
      </Step>

      {/* Actions */}
      <div className="sticky bottom-4 z-20 no-print flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-card/95 p-4 shadow-lg backdrop-blur">
        <Button variant="ghost" size="sm" onClick={handleReset}>
          <RotateCcw className="mr-1 h-4 w-4" /> Очистить
        </Button>
        <div className="flex flex-wrap gap-2">
          <Button onClick={handleGenerate} size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
            <FileText className="mr-2 h-4 w-4" /> Сформировать документы
          </Button>
        </div>
      </div>

      {/* Preview */}
      {generated && docs.length > 0 && (
        <section id="preview" className="rounded-xl border border-border bg-card p-6 md:p-8">
          <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-2xl font-serif">Готовые документы</h2>
            <div className="flex flex-wrap gap-2 no-print">
              <Button onClick={() => downloadAllZip(docs)} variant="outline" size="sm">
                <FileDown className="mr-1 h-4 w-4" /> Скачать всё (ZIP)
              </Button>
            </div>
          </header>

          <Tabs value={activeDoc} onValueChange={setActiveDoc}>
            <TabsList className="flex h-auto flex-wrap gap-1 bg-muted/60">
              {docs.map((d) => (
                <TabsTrigger key={d.id} value={d.id} className="text-xs md:text-sm">
                  {d.title.replace(/^Политика /, "").replace(/^Согласие на /, "Согл. ")}
                </TabsTrigger>
              ))}
            </TabsList>

            {docs.map((doc) => {
              const text = documentToText(doc);
              return (
                <TabsContent key={doc.id} value={doc.id} className="mt-5">
                  <div className="flex flex-wrap justify-end gap-2 no-print">
                    <Button size="sm" variant="outline" onClick={() => copy(text)}>
                      <Copy className="mr-1 h-4 w-4" /> Копировать текст
                    </Button>
                    <Button size="sm" onClick={() => downloadDocx(doc)} className="bg-accent text-accent-foreground hover:bg-accent/90">
                      <Download className="mr-1 h-4 w-4" /> Скачать .docx
                    </Button>
                  </div>
                  <article className="mt-4 max-h-[70vh] overflow-y-auto rounded-md border border-border bg-background p-6 leading-relaxed">
                    <h3 className="mb-4 text-center text-2xl font-serif">{doc.title}</h3>
                    {doc.sections.map((s, i) => (
                      <div key={i} className="mb-4">
                        {s.heading && (
                          <h4 className="mb-2 mt-3 font-serif text-lg font-semibold">{s.heading}</h4>
                        )}
                        {s.paragraphs.map((p, j) => (
                          <p key={j} className="mb-2 text-sm">
                            {p.split(/(\[НЕ ЗАПОЛНЕНО:[^\]]+\])/g).map((part, k) =>
                              part.startsWith("[НЕ ЗАПОЛНЕНО:") ? (
                                <mark key={k} className="rounded bg-destructive/15 px-1 text-destructive">
                                  {part}
                                </mark>
                              ) : (
                                <span key={k}>{part}</span>
                              ),
                            )}
                          </p>
                        ))}
                      </div>
                    ))}
                  </article>
                </TabsContent>
              );
            })}
          </Tabs>

          <p className="mt-6 text-xs text-muted-foreground">
            Сгенерированный текст — типовой шаблон. Перед публикацией рекомендуется проверка юристом и подача
            уведомления в Роскомнадзор при необходимости (ст. 22 152-ФЗ).
          </p>
        </section>
      )}
    </div>
  );
}
